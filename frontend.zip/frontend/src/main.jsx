import { BUILD_VERSION } from "./build_version";

import React from "react";
import ReactDOM from "react-dom/client";

// ❗ IMPORT CSS QUI
import "./index.css";

import App from "./App.jsx";

console.log("🔄 Build version:", BUILD_VERSION);

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App key={BUILD_VERSION} />
  </React.StrictMode>
);