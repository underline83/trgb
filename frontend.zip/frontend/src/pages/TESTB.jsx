export default function TESTB() {
  console.log(">>> TESTB.jsx ATTIVATA!");

  return (
    <div className="min-h-screen bg-green-100 p-10 text-center text-3xl">
      🟢 TEST B FUNZIONA
    </div>
  );
}