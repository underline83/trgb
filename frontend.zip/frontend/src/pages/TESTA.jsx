export default function TESTA() {
  console.log(">>> TESTA.jsx ATTIVATA!");

  return (
    <div className="min-h-screen bg-yellow-100 p-10 text-center text-3xl">
      🔶 TEST A FUNZIONA
    </div>
  );
}