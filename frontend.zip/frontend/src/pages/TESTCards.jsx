// @version: test
import React from "react";

export default function TESTCards() {
  console.log(">>> TESTCards ATTIVATO");

  return (
    <div className="bg-red-500 min-h-screen p-20 text-white text-4xl">
      CIAO — TEST FUNZIONA
    </div>
  );
}