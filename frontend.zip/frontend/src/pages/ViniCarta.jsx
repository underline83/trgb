// @version: v2.3-premium-stable
// Carta Vini — Anteprima HTML + PDF + Word
// Allineata al design “Vintage Premium”

import React, { useState } from "react";

export default function ViniCarta() {
  const [loading, setLoading] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);

  const refreshPreview = () => {
    setLoading(true);
    setReloadKey((k) => k + 1);
    setTimeout(() => setLoading(false), 600);
  };

  return (
    <div className="min-h-screen bg-neutral-100 p-6 font-sans">
      <div className="max-w-6xl mx-auto bg-white shadow-2xl rounded-3xl p-12 border border-neutral-200">

        {/* HEADER */}
        <h1 className="text-4xl font-bold text-center mb-3 text-amber-900 tracking-wide font-playfair">
          📜 Carta dei Vini — Anteprima
        </h1>
        <p className="text-center text-neutral-600 mb-10">
          Generata automaticamente dal database aggiornato.
        </p>

        {/* TOOLBAR */}
        <div className="flex flex-wrap items-center gap-4 bg-neutral-100 border border-neutral-300 rounded-xl p-5 shadow-inner mb-8">

          {/* AGGIORNA */}
          <button
            onClick={refreshPreview}
            disabled={loading}
            className={`px-6 py-3 rounded-xl text-white font-semibold shadow transition ${
              loading ? "bg-gray-400 cursor-not-allowed" : "bg-amber-700 hover:bg-amber-800"
            }`}
          >
            {loading ? "Aggiornamento…" : "🔄 Aggiorna Anteprima"}
          </button>

          {/* HTML */}
          <a
            href="http://127.0.0.1:8000/vini/carta"
            target="_blank"
            rel="noreferrer"
            className="px-5 py-3 rounded-xl text-amber-900 border border-amber-300 bg-amber-100 hover:bg-amber-200 transition shadow-sm font-medium"
          >
            🌐 Apri HTML
          </a>

          {/* PDF */}
          <button
            onClick={() => window.open("http://127.0.0.1:8000/vini/carta/pdf", "_blank")}
            className="px-6 py-3 rounded-xl text-amber-900 bg-yellow-200 border border-yellow-400 shadow hover:bg-yellow-300 transition font-semibold"
          >
            📄 Scarica PDF
          </button>

          {/* WORD */}
          <button
            onClick={() => window.open("http://127.0.0.1:8000/vini/carta/docx", "_blank")}
            className="px-6 py-3 rounded-xl text-blue-900 bg-blue-100 border border-blue-300 shadow hover:bg-blue-200 transition font-semibold"
          >
            📝 Scarica Word
          </button>
        </div>

        {/* ANTEPRIMA */}
        <div className="rounded-2xl shadow-2xl border border-neutral-300 bg-white overflow-hidden">

          {loading ? (
            <div className="h-[80vh] flex items-center justify-center text-amber-900 text-xl font-semibold animate-pulse">
              Caricamento della nuova carta…
            </div>
          ) : (
            <iframe
              key={reloadKey}
              src="http://127.0.0.1:8000/vini/carta"
              className="w-full"
              style={{
                height: "calc(100vh - 260px)",
                minHeight: "900px",
                border: "none",
              }}
              title="Anteprima Carta Vini"
            />
          )}

        </div>

      </div>
    </div>
  );
}