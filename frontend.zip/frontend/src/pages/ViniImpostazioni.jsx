// @version: v1.6-stable
// Impostazioni Carta Vini — UI Minimal Vintage TreGobbi
// @changelog:
//   - v1.6-stable (2025-11-13):
//       • ADD: nuovo filtro "mostra_senza_prezzo"
//       • UPDATE: lettura/scrittura completo dei 3 filtri
//   - v1.5-stable: versione precedente
//

import React, { useEffect, useState } from "react";
import {
  DragDropContext,
  Droppable,
  Draggable,
} from "@hello-pangea/dnd";

const API_BASE = "http://127.0.0.1:8000";

const api = {
  tipologie: `${API_BASE}/settings/vini/tipologie`,
  nazioni: `${API_BASE}/settings/vini/nazioni`,
  regioni: (n) => `${API_BASE}/settings/vini/regioni/${n}`,
  filtri: `${API_BASE}/settings/vini/filtri`,
  reset: `${API_BASE}/settings/vini/reset`,
};

export default function ImpostazioniVini() {
  const [tipologie, setTipologie] = useState([]);
  const [nazioni, setNazioni] = useState([]);
  const [regioni, setRegioni] = useState([]);
  const [selectedNation, setSelectedNation] = useState(null);

  const [filtri, setFiltri] = useState({
    min_qta_stampa: 1,
    mostra_negativi: false,
    mostra_senza_prezzo: false,
  });

  const [notif, setNotif] = useState("");

  const showNotif = (msg) => {
    setNotif(msg);
    setTimeout(() => setNotif(""), 1500);
  };

  useEffect(() => {
    loadTipologie();
    loadNazioni();
    loadFiltri();
  }, []);

  const loadTipologie = async () => {
    const r = await fetch(api.tipologie);
    setTipologie(await r.json());
  };

  const loadNazioni = async () => {
    const r = await fetch(api.nazioni);
    const data = await r.json();
    setNazioni(data);
    if (data.length > 0) loadRegioni(data[0].nazione);
  };

  const loadRegioni = async (nazione) => {
    setSelectedNation(nazione);
    const r = await fetch(api.regioni(nazione));
    setRegioni(await r.json());
  };

  const loadFiltri = async () => {
    const r = await fetch(api.filtri);
    const data = await r.json();

    setFiltri({
      min_qta_stampa: data.min_qta_stampa ?? 1,
      mostra_negativi: data.mostra_negativi ?? false,
      mostra_senza_prezzo: data.mostra_senza_prezzo ?? false,
    });
  };

  const saveFiltri = async () => {
    await fetch(api.filtri, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(filtri),
    });
    showNotif("Filtri salvati ✔️");
  };

  const resetSettings = async () => {
    if (!window.confirm("Ripristinare tutte le impostazioni ai valori di default?")) return;
    await fetch(api.reset, { method: "POST" });
    await loadTipologie();
    await loadNazioni();
    await loadRegioni("ITALIA");
    await loadFiltri();
    showNotif("Impostazioni ripristinate ✔️");
  };

  const saveOrder = async (type, items) => {
    const url =
      type === "tipologie"
        ? api.tipologie
        : type === "nazioni"
        ? api.nazioni
        : api.regioni(selectedNation);

    const body =
      type === "regioni"
        ? items.map((r) => ({ codice: r.codice, nome: r.nome }))
        : items.map((it) =>
            type === "tipologie" ? it.nome : it.nazione
          );

    await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });

    showNotif("Salvato ✔️");
  };

  const onDragEnd = (result, type) => {
    if (!result.destination) return;

    const items =
      type === "tipologie"
        ? Array.from(tipologie)
        : type === "nazioni"
        ? Array.from(nazioni)
        : Array.from(regioni);

    const [moved] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, moved);

    if (type === "tipologie") setTipologie(items);
    if (type === "nazioni") setNazioni(items);
    if (type === "regioni") setRegioni(items);

    saveOrder(type, items);
  };

  const Column = ({ title, items, type }) => (
    <div
      style={{
        background: "#fdf8f0",
        border: "1px solid #d8c7a1",
        borderRadius: "12px",
        padding: "20px",
        width: "100%",
        fontFamily: "Cormorant Garamond, serif",
        marginBottom: "24px",
      }}
    >
      <h2
        style={{
          fontSize: "22px",
          marginBottom: "16px",
          borderBottom: "1px solid #c5ab78",
          paddingBottom: "6px",
          letterSpacing: "0.5px",
        }}
      >
        {title}
      </h2>

      <DragDropContext onDragEnd={(r) => onDragEnd(r, type)}>
        <Droppable droppableId={type}>
          {(provided) => (
            <div ref={provided.innerRef} {...provided.droppableProps}>
              {items.map((item, index) => (
                <Draggable
                  key={item.nome || item.nazione || item.codice}
                  draggableId={item.nome || item.nazione || item.codice}
                  index={index}
                >
                  {(provided) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: "10px",
                        padding: "10px 14px",
                        marginBottom: "8px",
                        background: "white",
                        borderRadius: "8px",
                        border: "1px solid #e1d1b3",
                        fontSize: "17px",
                        ...provided.draggableProps.style,
                      }}
                    >
                      <div
                        {...provided.dragHandleProps}
                        style={{
                          cursor: "grab",
                          fontSize: "22px",
                          paddingRight: "8px",
                          color: "#a48a6b",
                          userSelect: "none",
                        }}
                      >
                        ⋮⋮
                      </div>

                      <div style={{ flex: 1 }}>
                        {type === "tipologie" && item.nome}
                        {type === "nazioni" && item.nazione}
                        {type === "regioni" &&
                          `${item.codice} — ${item.nome}`}
                      </div>
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>
    </div>
  );

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        gap: "28px",
        padding: "28px",
        background: "#f5f0e8",
        minHeight: "100vh",
      }}
    >
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: "-10px",
        }}
      >
        <h1 style={{ fontFamily: "Cormorant Garamond", fontSize: "32px" }}>
          Impostazioni Carta Vini
        </h1>

        <button
          onClick={resetSettings}
          style={{
            padding: "8px 20px",
            borderRadius: "8px",
            border: "1px solid #b28a4a",
            background: "#e0c08a",
            fontSize: "16px",
            cursor: "pointer",
          }}
        >
          Ripristina default
        </button>
      </div>

      <Column title="Tipologie" items={tipologie} type="tipologie" />

      <Column title="Nazioni" items={nazioni} type="nazioni" />

      <div>
        <div
          style={{
            marginBottom: "12px",
            fontFamily: "Cormorant Garamond, serif",
            fontSize: "18px",
          }}
        >
          Regione →
          <select
            value={selectedNation || ""}
            onChange={(e) => loadRegioni(e.target.value)}
            style={{
              padding: "4px 10px",
              marginLeft: "6px",
              background: "white",
              borderRadius: "6px",
              border: "1px solid #b8a584",
              fontSize: "16px",
            }}
          >
            {nazioni.map((n) => (
              <option key={n.nazione} value={n.nazione}>
                {n.nazione}
              </option>
            ))}
          </select>
        </div>

        <Column
          title={`Regioni di ${selectedNation || "-"}`}
          items={regioni}
          type="regioni"
        />
      </div>

      <div
        style={{
          background: "#fdf8f0",
          border: "1px solid #d8c7a1",
          borderRadius: "12px",
          padding: "20px",
          fontFamily: "Cormorant Garamond",
        }}
      >
        <h2
          style={{
            fontSize: "22px",
            marginBottom: "16px",
            borderBottom: "1px solid #c5ab78",
            paddingBottom: "6px",
          }}
        >
          Filtri di stampa Carta Vini
        </h2>

        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            gap: "18px",
            alignItems: "center",
          }}
        >
          <label style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "17px" }}>
            Quantità minima per stampare:
            <input
              type="number"
              min={0}
              value={filtri.min_qta_stampa}
              onChange={(e) =>
                setFiltri((prev) => ({
                  ...prev,
                  min_qta_stampa: parseInt(e.target.value || "0", 10),
                }))
              }
              style={{
                width: "80px",
                padding: "4px 6px",
                borderRadius: "6px",
                border: "1px solid #b8a584",
              }}
            />
          </label>

          <label style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "17px" }}>
            <input
              type="checkbox"
              checked={filtri.mostra_negativi}
              onChange={(e) =>
                setFiltri((prev) => ({
                  ...prev,
                  mostra_negativi: e.target.checked,
                }))
              }
            />
            Includi vini con quantità negativa
          </label>

          <label style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "17px" }}>
            <input
              type="checkbox"
              checked={filtri.mostra_senza_prezzo}
              onChange={(e) =>
                setFiltri((prev) => ({
                  ...prev,
                  mostra_senza_prezzo: e.target.checked,
                }))
              }
            />
            Includi vini senza prezzo
          </label>

          <button
            onClick={saveFiltri}
            style={{
              marginLeft: "auto",
              padding: "8px 16px",
              borderRadius: "8px",
              border: "1px solid #b28a4a",
              background: "#e2c79b",
              cursor: "pointer",
              fontSize: "16px",
            }}
          >
            Salva filtri
          </button>
        </div>
      </div>

      {notif && (
        <div
          style={{
            position: "fixed",
            bottom: "20px",
            right: "20px",
            background: "#e7d8b8",
            border: "1px solid #bfa36b",
            padding: "10px 18px",
            borderRadius: "8px",
            fontFamily: "Cormorant Garamond, serif",
            fontSize: "16px",
            boxShadow: "0px 3px 10px rgba(0,0,0,0.15)",
            zIndex: 9999,
          }}
        >
          {notif}
        </div>
      )}
    </div>
  );
}