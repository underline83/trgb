// @version: test-1.0
import React from "react";
import { Link } from "react-router-dom";

export default function TESTPagina() {
  console.log(">>> TESTPagina.jsx CARICATA");

  return (
    <div className="min-h-screen bg-red-100 p-6">
      <div className="max-w-3xl mx-auto bg-white p-10 rounded-3xl shadow-2xl border border-red-400">
        
        <h1 className="text-4xl font-bold text-center text-red-700 mb-6">
          🔥 PAGINA DI TEST — SE LA VEDI, IL RENDER FUNZIONA
        </h1>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">

          <Link
            to="/test/a"
            className="bg-red-200 border border-red-500 p-8 rounded-2xl cursor-pointer shadow-lg hover:shadow-xl transition"
          >
            <h2 className="text-xl font-bold text-red-800">Vai a TEST A</h2>
          </Link>

          <Link
            to="/test/b"
            className="bg-blue-200 border border-blue-500 p-8 rounded-2xl cursor-pointer shadow-lg hover:shadow-xl transition"
          >
            <h2 className="text-xl font-bold text-blue-900">Vai a TEST B</h2>
          </Link>

        </div>

      </div>
    </div>
  );
}