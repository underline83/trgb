// @version: v2.4-test
import React, { useState } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import Login from "./pages/Login";
import Home from "./pages/Home";

import ViniMenu from "./pages/ViniMenu";
import ViniCarta from "./pages/ViniCarta";
import ViniDatabase from "./pages/ViniDatabase";
import ViniVendite from "./pages/ViniVendite";
import ViniImpostazioni from "./pages/ViniImpostazioni";

// 🔥 PAGINE TEST (debug per capire se il router funziona)
import TESTPagina from "./pages/TESTPagina";
import TESTA from "./pages/TESTA";
import TESTB from "./pages/TESTB";
import TESTCards from "./pages/TESTCards";

export default function App() {
  const [token, setToken] = useState(localStorage.getItem("token"));
  const [role, setRole] = useState(localStorage.getItem("role"));

  if (!token) return <Login setToken={setToken} setRole={setRole} />;

  return (
    <BrowserRouter>
      <Routes>

        {/* HOME */}
        <Route path="/" element={<Home />} />

        {/* --- GESTIONE VINI --- */}
        <Route path="/vini" element={<ViniMenu />} />
        <Route path="/vini/carta" element={<ViniCarta />} />
        <Route path="/vini/database" element={<ViniDatabase />} />
        <Route path="/vini/vendite" element={<ViniVendite />} />
        <Route path="/vini/settings" element={<ViniImpostazioni />} />

        {/* --- PAGINE DI DEBUG --- */}
        <Route path="/test" element={<TESTPagina />} />
        <Route path="/test/a" element={<TESTA />} />
        <Route path="/test/b" element={<TESTB />} />
        <Route path="/testcards" element={<TESTCards />} />

      </Routes>
    </BrowserRouter>
  );
}